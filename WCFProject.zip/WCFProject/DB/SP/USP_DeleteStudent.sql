CREATE PROCEDURE DeleteStudent(
 @student_id_with_prefix VARCHAR(50))
AS
BEGIN
    DELETE from StudentTable where student_Id_with_prefix=@student_id_with_prefix
END;

EXEC DeleteStudent 'STD00003'

SELECT * FROM StudentTable

