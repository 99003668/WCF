
CREATE PROCEDURE GetStudentByID
   @student_id_with_prefix VARCHAR(50)
AS
BEGIN
    --IF EXISTS (SELECT 1 FROM StudentTable WHERE student_Id_with_prefix = @student_Id_with_prefix)
    --BEGIN
        SELECT 
            student_Id_with_prefix,
            student_name,
            dob,
            contact,
			student_address
        FROM 
            StudentTable
        WHERE 
            student_Id_with_prefix=@student_id_with_prefix
    --END
    --ELSE
    --BEGIN
    --    Return 0 ;
    --END
END;


EXEC GetStudentByID 'STD00004'

SELECT * FROM StudentTable

