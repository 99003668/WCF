CREATE PROCEDURE UpdateStudent(
 @student_id_with_prefix VARCHAR(50),
 @student_name VARCHAR(100),
 @dob DATE,
 @gender CHAR(1),
 @contact VARCHAR(20),
 @student_address VARCHAR(255))
AS
BEGIN
    UPDATE StudentTable
    SET student_name = @student_name,
        dob = @dob,
        gender = @gender,
		contact=@contact,
		student_address=@student_address
    WHERE student_id_with_prefix = @student_id_with_prefix ;
END;

EXEC UpdateStudent 'STD00003','Prasanna', '1999-06-03', 'F', '7989511873', 'D.NO:123-12,TPG,AP-534101'
SELECT * FROM StudentTable

