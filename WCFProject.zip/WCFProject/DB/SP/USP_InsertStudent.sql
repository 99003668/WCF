CREATE PROCEDURE USP_InsertStudent

 @student_name VARCHAR(100),
 @dob DATE,
 @gender CHAR(1),
 @contact VARCHAR(20),
 @student_address VARCHAR(255)
AS
BEGIN
INSERT INTO StudentTable(student_name, dob, gender, contact, student_address) 
VALUES(@student_name,@dob,@gender,@contact,@student_address);
END

EXEC USP_InsertStudent 'Geethika', '1998-01-03', 'F', '1234567890', '1-1-1,Mysore'

EXEC USP_InsertStudent 'Prasanna', '2000-06-03', 'F', '3216549870', '123-12,Hyd'

EXEC USP_InsertStudent 'Keerthi', '1997-06-03', 'F', '7321654987', '325-96,Pune'

SELECT * FROM StudentTable

--DELETE from StudentTable where student_Id_with_prefix='STD00002';
