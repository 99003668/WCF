CREATE TABLE StudentTable(
    student_id INT IDENTITY(1,1),
    student_prefix VARCHAR(3) DEFAULT 'STD',
    student_id_with_prefix AS (student_prefix + RIGHT('00000' + CAST(student_id AS VARCHAR(5)), 5)),
    student_name VARCHAR(100),
    dob DATE,
    gender CHAR(1),
    contact VARCHAR(20),
    student_address VARCHAR(255),
    CONSTRAINT PK_Student PRIMARY KEY (student_id)
);

INSERT INTO StudentTable(student_name, dob, gender, contact, student_address)
VALUES ('SIRISHA', '1999-06-03', 'F', '7989511873', 'D.NO:123-12,TPG,AP-534101');

SELECT * FROM StudentTable