﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace StudentWcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        void InsertStudent(Student objStudent);

        [OperationContract]
        void UpdateStudent(Student objStudent);

        [OperationContract]
        void DeleteStudent(string StudentID);

        [OperationContract]
        Task<List<Student>> SearchStudentByIDAsync(string studentID);
    }

    [DataContract]
    public class ServiceError
    {
        [DataMember]
        public string ErrorMessage { get; set; }
    }

    [DataContract]
    public class Student
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public DateTime DOB { get; set; }

        [DataMember]
        public string Contact { get; set; }

        [DataMember]
        public char Gender { get; set; }

        [DataMember]
        public string Address { get; set; }
    }
}
