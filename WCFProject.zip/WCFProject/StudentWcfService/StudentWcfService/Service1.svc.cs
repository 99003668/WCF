﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace StudentWcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        public void InsertStudent(Student objStudent)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("USP_InsertStudent", connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@student_name", objStudent.Name);
                command.Parameters.AddWithValue("@dob", objStudent.DOB);
                command.Parameters.AddWithValue("@gender", objStudent.Gender);
                command.Parameters.AddWithValue("@contact", objStudent.Contact);
                command.Parameters.AddWithValue("@student_address", objStudent.Address);


                command.ExecuteNonQuery();
            }
        }

        public void UpdateStudent(Student objStudent)
        {
            if (StudentExists(objStudent.Id))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("UpdateStudent", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@student_id_with_prefix",objStudent.Id);
                    command.Parameters.AddWithValue("@student_name", objStudent.Name);
                    command.Parameters.AddWithValue("@dob", objStudent.DOB);
                    command.Parameters.AddWithValue("@gender", objStudent.Gender);
                    command.Parameters.AddWithValue("@contact", objStudent.Contact);
                    command.Parameters.AddWithValue("@student_address", objStudent.Address);


                    command.ExecuteNonQuery();
                }
            }
        }
        private bool StudentExists(string studentID)
        {
            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM StudentTable WHERE  student_id_with_prefix = @student_id_with_prefix", connection);
                command.Parameters.AddWithValue("@student_id_with_prefix", studentID);

                connection.Open();
                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        public void DeleteStudent(string studentID)
        {
            if(StudentExists(studentID))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("DeleteStudent", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@student_id_with_prefix", studentID);

                    command.ExecuteNonQuery();
                }

            }
        }


        public async Task<List<Student>> SearchStudentByIDAsync(string studentID)
        {
            try
            {
                if (StudentExists(studentID))
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand("GetStudentByID", connection);
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@student_id_with_prefix", studentID);

                        await connection.OpenAsync();

                        List<Student> students = new List<Student>();

                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                string genderString = reader.IsDBNull(reader.GetOrdinal("gender")) ? null : reader.GetString(reader.GetOrdinal("gender"));
                                char genderChar = !string.IsNullOrEmpty(genderString) ? genderString[0] : '\0';

                                Student student = new Student
                                {
                                    Id = reader.GetString(reader.GetOrdinal("student_id_with_prefix")),
                                    Name = reader.GetString(reader.GetOrdinal("student_name")),
                                    DOB = reader.GetDateTime(reader.GetOrdinal("dob")),
                                    //Gender = reader.GetChar(reader.GetOrdinal("gender")),
                                    Contact = reader.GetString(reader.GetOrdinal("contact")),                                   
                                    Address = reader.GetString(reader.GetOrdinal("student_address")),
                                    Gender = genderChar

                                };

                                students.Add(student);

                            }

                        }

                        return students;
                    }
                }


                return new List<Student>();
            }
            catch(Exception ex)
            {
                var exc = ex;
                return new List<Student>();
            }

        }

    }
}
