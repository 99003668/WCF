﻿using Client.StudentServiceReference;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Client.StudentServiceReference;

namespace Client
{
    public partial class StudentForm : Form
    {
        StudentServiceReference.Service1Client client = new StudentServiceReference.Service1Client();

        bool IsExists;
        public StudentForm()
        {
            InitializeComponent();
            dataGridView1.Columns["id"].ReadOnly = true;
        }

        //private void AddRow()
        //{
        //    dataGridView1.Rows.Add();
        //}

        #region Search
        private async void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string studentID = textBox1.Text;
                var result = await client.SearchStudentByIDAsync(studentID);
                if (result != null && result.Length != 0)
                {
                    dataGridView1.AutoGenerateColumns = true;
                    dataGridView1.DataSource = result;
                    //dataGridView1.Visible = true;
                    //dataGridView1.AllowUserToAddRows = true;
                    //AddRow();
                    dataGridView1.Columns["id"].ReadOnly = true;
                    dataGridView1.Refresh();
                    
                }
                else
                {
                    string logMessage = "No student found for ID: " + studentID;
                    MessageBox.Show(logMessage, "Student Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching for student: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        #endregion


        #region AddUsing Enter
        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dataGridView1.Rows.Add();
                int newRowIdx = dataGridView1.Rows.Count - 1;

                //string fieldValue1 = dataGridView1.Rows[newRowIdx].Cells["Column1"].Value?.ToString();
                string fieldValue2 = dataGridView1.Rows[newRowIdx].Cells["Column2"].Value?.ToString();
                DateTime fieldValue3= DateTime.MinValue;
                DataGridViewCell cell3 = dataGridView1.Rows[newRowIdx].Cells["Column3"];
                if (cell3.Value != null && cell3.Value is DateTime)
                {
                    fieldValue3 = (DateTime)cell3.Value;
                }
                char fieldValue4='F';
                string cellValue4 = dataGridView1.Rows[newRowIdx].Cells["Column4"].Value?.ToString();
                if (!string.IsNullOrEmpty(cellValue4) && cellValue4.Length == 1)
                {
                    fieldValue4 = cellValue4[0];
                }
                string fieldValue5 = dataGridView1.Rows[newRowIdx].Cells["Column5"].Value?.ToString();
                string fieldValue6 = dataGridView1.Rows[newRowIdx].Cells["Column6"].Value?.ToString();

                Student newStudent = new Student
                {
                    //Id = fieldValue1,
                    Name = fieldValue2,
                    DOB = fieldValue3,
                    Gender = fieldValue4,
                    Contact = fieldValue5,
                    Address = fieldValue6                   
                };

                if (newStudent != null)
                {
                    client.InsertStudent(newStudent);
                }
                else
                {
                    MessageBox.Show("Failed to create student. Please check the entered data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion


        #region Insert
        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                
                if (!row.IsNewRow )
                {
                    
                    //string id = row.Cells["IdColumn"].Value?.ToString();
                    string name = row.Cells["name"].Value?.ToString();
                    char gender = '\0'; // Default value
                    string genderString = row.Cells["gender"].Value?.ToString();
                    if (!string.IsNullOrEmpty(genderString) && genderString.Length == 1)
                    {
                        gender = genderString[0];
                    }
                    DateTime dob= DateTime.MinValue;
                    if (row.Cells["dob"].Value != null && DateTime.TryParse(row.Cells["dob"].Value.ToString(), out dob))
                    {
                        
                    }
                    string contact = row.Cells["contact"].Value?.ToString();
                    string address = row.Cells["address"].Value?.ToString();
                    
                    Student newStudent = new Student
                    {
                        //Id = id,
                        Name = name,
                        Gender = gender,
                        Address = address,
                        Contact = contact,
                        DOB = dob
                        
                    };

                    
                    client.InsertStudent(newStudent);
                    dataGridView1.DataSource = null;
                    dataGridView1.Refresh();                    
                }
                
            }
            MessageBox.Show("Student Successfully Inserted");
        }
        #endregion

        #region Update
        private void button3_Click(object sender, EventArgs e)
        {
            //if (dataGridView1.SelectedRows.Count == 0)
            //{
            //    MessageBox.Show("Please select a record to update.", "No Record Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    string id = row.Cells["id"].Value?.ToString();
                    string name = row.Cells["name"].Value?.ToString();
                    char gender = '\0'; // Default value
                    string genderString = row.Cells["gender"].Value?.ToString();
                    if (!string.IsNullOrEmpty(genderString) && genderString.Length == 1)
                    {
                        gender = genderString[0];
                    }
                    DateTime dob = DateTime.MinValue;
                    if (row.Cells["dob"].Value != null && DateTime.TryParse(row.Cells["dob"].Value.ToString(), out dob))
                    {

                    }
                    string contact = row.Cells["contact"].Value?.ToString();
                    string address = row.Cells["address"].Value?.ToString();

                    Student newStudent = new Student
                    {
                        Id = id,
                        Name = name,
                        Gender = gender,
                        Address = address,
                        Contact = contact,
                        DOB = dob

                    };

                    client.UpdateStudent(newStudent);
                    MessageBox.Show("Data Successfully Updated");
                }
            }

            
        }

        #endregion

        private async Task<bool> DoesStudentExist(string studentID)
        {
            try
            {
                // Call the SearchStudentByIDAsync method to search for the student
                var result = await client.SearchStudentByIDAsync(studentID);
                
                if(result == null && result.Length==0)
                {
                   IsExists= true;
                }
                
                return result!=null;
            }
            catch (Exception ex)
            {
                
                Console.WriteLine("An error occurred while checking if student exists: " + ex.Message);
                return false; 
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
               foreach (DataGridViewRow row in dataGridView1.Rows)
               {
                    if (!row.IsNewRow)
                    {
                        string id = row.Cells["id"].Value?.ToString();
                        client.DeleteStudent(id);
                        var result = client.SearchStudentByIDAsync(id);
                        if (IsExists)
                        {
                            MessageBox.Show("Student data deleted successfully");
                        }
                        else
                        {
                            MessageBox.Show("Student data not deleted");
                        }
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

}
